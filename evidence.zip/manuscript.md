# Research note

AI-assisted research draft. Methodology, contributions and review status are described in Section 11 and the companion methodology note.

# Abstract

For a connected graph G and a minimum resolving set B, we consider the minimum cardinality rho(G,B) of a fault-tolerant resolving set containing B, and compare it with the unconstrained fault-tolerant metric dimension beta2(G). The difference p(G,B)=rho(G,B)-beta2(G) measures a cardinality penalty for retaining the original base. Using established ordinary-resolution characterizations for unicyclic graphs, we prove that p(G,B)<=1 for every metric basis of every connected simple unweighted subcubic unicyclic graph, and give a seven-vertex example attaining equality. An accompanying exact enumeration through ten vertices checks 331 graph classes and all 3,900 bases: 3,761 bases have penalty zero and 139 have penalty one. A separately authored computational audit verifies coverage, all optima and 237,928 subset certificate entries. This is a narrow structural result in pure graph theory; it does not establish an efficient optimization algorithm or a physical sensor-deployment improvement.

# 1. Problem and literature context

Ordinary metric dimension minimizes the number of vertices needed to distinguish all vertices by their distance vectors. Fault-tolerant metric dimension requires resilience to erasure of a sensor coordinate. We study the additional cost of retaining an arbitrary prescribed metric basis when upgrading a unicyclic graph to one-fault-tolerant resolution. For connected subcubic unicyclic graphs, this cost relative to an unconstrained optimal fault-tolerant resolving set is at most one, and the bound is sharp.

Preserving a given resolving set during augmentation is established prior art. Hernando, Mora, Slater and Wood [@hernando-ft, Lemma 3.1] start with a given resolving set and construct a fault-tolerant superset using closed neighborhoods and additional neighborhood-containment witnesses. Their Theorem 3.3 gives a bound in terms of ordinary metric dimension. Their Remark 2.4 allows arbitrary choices of two vertices in the two terminal paths of a tree stem with exactly two terminal paths, preceding the local freedom used in our terminal-fork exchange. Our comparison concerns the *optimal* superset of a specified basis relative to the unconstrained fault-tolerant optimum, rather than claiming augmentation itself as new.

Sedlar and Skrekovski [@sedlar-skrekovski] provide the ordinary unicyclic resolving-set characterization essential to the proof. Their Lemmas 1, 3, 6 and 7 supply branch coverage, biactivity, geodesic triples and the A/B/C obstruction characterization; Theorem 11 gives ordinary dimension. Our exchange lemma is an application/corollary of that characterization, with the tree predecessor just noted. It is not a new characterization or a separate major novelty claim. The one-branch-root repair and antipodal completion supply additional arguments for the prescribed-basis comparison.

Knor, Sedlar and Skrekovski [@knor-expensive] study how expensive fault tolerance can be relative to ordinary metric dimension, including exponential growth and higher multiplicities. Although the language includes upgrading a metric basis, the optimized invariant is unconstrained fault-tolerant dimension. Geneson and Tsai [@geneson-tsai, Section 2 and the proof of Theorem 2.7] explicitly extend arbitrary resolving sets using their closed neighborhoods and further witnesses, another predecessor for basis-preserving augmentation. Their stated bounds and extremal questions concern ordinary dimension. The inspected arXiv version has differing constants in its abstract and Theorem 2.7; no exact numerical bound from it is used here.

Related terminology has different quantifiers. Hakanen et al. [@hakanen-forced] study vertices contained in every or in no minimum ordinary metric basis, rather than vertices imposed as part of an input. Their Section 3.1.1 also records the known dimension-two result for odd type-1 unicyclic graphs and dimension-two-or-three result for even ones, attributing these to Poisson and Zhang (2002). Our branch-free dimension facts are therefore acknowledged as known; the explicit odd-cycle calculation below is included for completeness. Bergougnoux, Defrain and Mc Inerney [@bergougnoux-enumerating, Sections 6-7] use extension problems with required and forbidden vertices in enumeration of inclusion-minimal solutions. Ordinary inclusion-minimal extension differs from minimum-cardinality fault-tolerant augmentation of an already minimum basis.

Estrada-Moreno [@estrada-unicyclic] studies k-metric dimension; k=2 is the unconstrained fault-tolerant invariant here. Theorems 4-5 concern type-1 graphs with exactly one degree-three cycle vertex; Theorem 6 concerns at least three special branching vertices under further hypotheses. These do not state an extension guarantee for every prescribed minimum basis. Our seven-vertex witness has two degree-three cycle vertices, so it is not the single-pendant-path case. Prabhu et al. [@prabhu-primary, version 2] use attaching fault-tolerant sets chosen outside an attachment set: their additional selected vertices are subject to deletion while the designated attachments remain available. Here every sensor, including every member of B, is subject to erasure. Their point-attachment formulas also have structural conditions.

We did not find this prescribed-basis comparison in the sources checked. The result-specific public-source search, completed on 18 October 2026, judged the sharp theorem apparently new with moderate confidence, not an originality guarantee. The approximately ten-minute search covered English-language indexed literature and adjacent references, including fixed/prescribed/forced landmarks, extensions, supersets, exchange and disjoint resolving sets. A second terminology pass was by the same searcher, not an independent second literature review. It was not an exhaustive MathSciNet/zbMATH search and incompletely covered theses, non-English and unindexed work or unavailable texts. A potentially relevant pseudotree survey was identified but not retrieved and is not used to certify absence of prior art. No authors were contacted. No separate priority claim is made for the elementary union bound, the standard graph family or the technical exchange lemma.

# 2. Definitions and conventions

Graphs in the original pilot are finite, connected, simple, undirected and unweighted. Let d_G(u,v) be the number of edges in a shortest u-v path. For distinct u,v define

\[
D_G(u,v)=\{s\in V(G):d_G(u,s)\ne d_G(v,s)\}.
\]

A set S resolves G when S intersects every D_G(u,v). Its minimum possible size is beta(G). We call a resolving set B a metric basis only when |B|=beta(G); mere inclusion-minimality is insufficient.

A set S is fault-tolerant when |S intersect D_G(u,v)|>=2 for every distinct pair u,v. Equivalently, S without s resolves G for each s in S, with the empty set excluded on the graphs considered here. To see equivalence, two distinguishers leave at least one after any erasure. If a pair has at most one distinguisher, either it is already unresolved or erasure of that sole distinguisher makes it unresolved. Distances are always taken in the unchanged graph G. Erasing a sensor does not delete its vertex, incident edges or paths through it. The failed sensor vertex remains in the target population and distances are not recomputed.

Write FT(G) for the family of fault-tolerant sets and define

\[
\beta_2(G)=\min_{S\in\operatorname{FT}(G)}|S|,\qquad
\rho(G,B)=\min_{S\in\operatorname{FT}(G),\,B\subseteq S}|S|,
\qquad p(G,B)=\rho(G,B)-\beta_2(G).
\]

The subscript in beta2 denotes the two-distinguishers condition; it is not an assertion that every cited source uses identical notation. All optima exist: for every pair u,v, both u and v distinguish that pair, so V(G) is fault-tolerant. Containment restricts feasible sets, hence p(G,B)>=0. The quantity rho counts all sensors in the superset; rho-|B| counts additions. These are different statistics.

A connected graph is unicyclic when it has exactly one cycle; for a simple connected graph this is equivalent to |E|=|V|. Subcubic means maximum degree at most three. The finite domain is 3<=|V|<=10; no simple unicyclic graph has fewer than three vertices. Pure cycles are included.

# 3. Audited finite result

**Computational Result 1 (finite domain).** For every connected simple unweighted subcubic unicyclic graph G with 3<=|V(G)|<=10, and for every metric basis B of G, p(G,B)<=1. In this domain both values zero and one occur.

This statement is supported by exhaustive integer computation, the coverage arguments in Section 4 and an independent executable audit. It is not a proof-assistant-checked theorem and is not asserted for orders above ten.

| Order n | Graph classes | Metric bases | Bases with p=0 | Bases with p=1 | Graphs admitting p=1 |
|---:|---:|---:|---:|---:|---:|
| 3 | 1 | 3 | 3 | 0 | 0 |
| 4 | 2 | 9 | 9 | 0 | 0 |
| 5 | 4 | 29 | 29 | 0 | 0 |
| 6 | 9 | 74 | 74 | 0 | 0 |
| 7 | 17 | 175 | 170 | 5 | 2 |
| 8 | 38 | 407 | 394 | 13 | 5 |
| 9 | 80 | 971 | 943 | 28 | 11 |
| 10 | 180 | 2,232 | 2,139 | 93 | 27 |
| Total | 331 | 3,900 | 3,761 | 139 | 45 |

These are unweighted counts of bases on one labeled representative per isomorphism class, not counts over all n! relabelings and not counts modulo automorphisms of a representative. Every tied minimum base is retained. The displayed relative frequencies therefore describe this counting convention rather than a random-graph probability model.

# 4. Complete generation and equivalence reduction

## 4.1. Spanning-tree construction

**Proposition 2 (coverage).** Every subcubic unicyclic graph on n vertices is produced by taking a subcubic tree on n vertices and adding a non-edge whose endpoints have tree degree at most two.

*Proof.* Delete an edge of the graph's unique cycle. The resulting graph is a spanning tree and remains subcubic. The endpoints of the deleted edge each lose one incident edge and therefore have degree at most two. The original graph is recovered by adding that non-edge. Conversely, adding a non-edge to a tree creates one cycle and preserves connectivity; the endpoint restriction preserves maximum degree three. The graph is simple because an existing edge is never added. QED.

All subcubic trees are generated inductively by adding a new leaf at each vertex of degree at most two, starting with one vertex. Deleting any leaf of any nontrivial subcubic tree yields a smaller subcubic tree and makes the original attachment vertex eligible for reattachment. Induction therefore establishes coverage. Deduplication is applied at every order, but no structural subclass is sampled or omitted.

## 4.2. Exact isomorphism keys

A rooted tree is encoded recursively by a matched parenthesis pair enclosing its sorted child encodings. Induction on size shows that two encodings agree exactly when the rooted trees are isomorphic: the sorted child lists agree precisely as multisets of rooted isomorphism classes. For an unrooted tree the primary implementation takes the minimum such encoding over all choices of root. Equality gives an isomorphism for a pair of roots, while an unrooted isomorphism induces a bijection of the root choices.

For a unicyclic graph, repeatedly peeling leaves identifies its unique cycle. At each cycle vertex, encode the rooted off-cycle attachment, excluding the cycle edges. Form the sequence of these rooted codes in cycle order. The canonical key is the least sequence over all cyclic rotations and both orientations, with explicit separators and cycle length. An isomorphism must map the unique cycle to the unique cycle and acts on it by a dihedral symmetry; it also induces rooted isomorphisms of the attachments. Conversely, matching sequences and attachment isomorphisms assemble to a graph isomorphism. Thus these full strings, rather than hash collisions or numerical invariants, decide equality of primary graph classes.

## 4.3. Separate coverage construction

A second construction chooses cycle length k, distributes n-k vertices among its k positions, and attaches either nothing or one rooted tree at each position. Every off-cycle vertex has at most two children; each cycle vertex has at most one off-cycle child. Recursive generation of unordered zero-, one- and two-child rooted trees covers all such attachments. Cutting the unique cycle edges of any target graph shows that every target has this form.

The same-task verifier deduplicated and matched these constructions through exact degree-preserving adjacency backtracking, independently of the primary canonical equality routine. The separate external auditor independently implemented the cycle/attachment construction and canonical encoding and obtained the same class set at every order. The external construction is independently authored; it is not claimed to be a third distinct structural characterization beyond the tree-addition and cycle-attachment routes.

## 4.4. Why representatives suffice for all labels and bases

An isomorphism f preserves distances. It therefore carries resolving sets and fault-tolerant sets bijectively to their counterparts, preserves cardinalities and preserves containment B subseteq S. Consequently beta, beta2, rho and p are invariant under simultaneous transport of G and B. Since every minimum base of each chosen representative is explicitly checked, every base on every relabeling is covered. No reduction to a single base or a single favorable tie is used.

# 5. Exact optimization and certificates

The primary implementation computes shortest-path distances by breadth-first search. Vertices are labeled 0,...,n-1; bit i of a mask denotes vertex i. For each unordered pair it stores the integer mask of D_G(u,v). It visits all 2^n subsets and tests whether every pair has at least one or at least two selected distinguishers. Minimum cardinalities give beta and beta2, and all resolving masks at cardinality beta are retained. For each such B it scans the fault-tolerant masks containing B and minimizes their total cardinality. Tied optimum witnesses are chosen by increasing integer mask; choosing one witness does not discard any minimum base.

Each graph record contains its edge list, distance matrix, beta, beta2 and an optimum fault-tolerant witness. Each base record contains B, rho, p and an optimum superset. The complete subset certificate records its cardinality and, when a condition fails, a concrete vertex pair witnessing failure. These records certify lower bounds through exhaustive failed smaller subsets as well as upper bounds through feasible sets. At n<=10 there are at most 1,024 subsets and 45 pairs per graph. The direct base/superset comparison is bounded by 4^n comparisons per graph. All arithmetic relevant to the mathematics is integer arithmetic.

The same-task verifier instead uses Floyd-Warshall distances and tuple combinations. Resolving is tested by uniqueness of vertex distance signatures; fault tolerance is tested by deletion of each sensor coordinate. A subsequent serialization audit parses the saved outputs and repeats verification. It also checks 1,182 deterministic relabelings for canonical-key invariance and transport of witness containment/cardinality. These relabeling tests supplement, rather than replace, the exact isomorphism argument.

The external auditor wrote its core before examining the original implementation or saved result contents. It imports no pilot module. It computes distances by BFS, constructs all subset signature tables and tests one-coordinate deletion. It checks every recorded optimum, the complete base families, all 237,928 subset entries, distance matrices and all supplied obstruction pairs. Its audit does not depend on the convention that an optimum witness or failing pair is lexicographically first. The external verdict is PASS for the finite domain. The source hashes remained unchanged during its successful run.

# 6. A seven-vertex example with a direct proof

Let V={0,1,2,3,4,5,6} and

\[
E=\{01,02,03,14,25,45,56\}.
\]

Here ij denotes the undirected edge {i,j}. The cycle is 0-1-4-5-2-0; leaves 3 and 6 attach to 0 and 5. Let B={0,5}.

**Proposition 3.** This graph and base satisfy beta(G)=2, beta2(G)=3 and rho(G,B)=4, hence p(G,B)=1.

*Proof.* The following table gives signatures in the indicated sensor order.

| Vertex | B=(0,5) | C=(1,2) | T=(1,2,3) |
|---:|---|---|---|
| 0 | (0,2) | (1,1) | (1,1,1) |
| 1 | (1,2) | (0,2) | (0,2,2) |
| 2 | (1,1) | (2,0) | (2,0,2) |
| 3 | (1,3) | (2,2) | (2,2,0) |
| 4 | (2,1) | (1,2) | (1,2,3) |
| 5 | (2,0) | (2,1) | (2,1,3) |
| 6 | (3,1) | (3,2) | (3,2,4) |

Every B-signature is distinct, so B resolves. No singleton resolves: for singleton sensors 0,1,2,3,4,5,6 respectively, the equal-distance pairs {1,2}, {0,4}, {0,5}, {1,2}, {0,2}, {0,1}, {0,1} are obstructions. Hence beta(G)=2 and B is a metric basis.

Every two distinct T-signatures differ in at least two coordinates, as direct inspection of the seven displayed triples verifies. Thus T is fault-tolerant and beta2<=3. If a set of cardinality at most two were fault-tolerant, erasing a sensor would leave at most a singleton resolving set, impossible here. Hence beta2=3.

There are five possible size-three supersets of B. The following table gives a pair with only one distinguishing sensor in each, together with that sensor. Its erasure causes the displayed collision.

| Added vertex a | Pair | Sole distinguishing sensor in B union {a} |
|---:|---|---:|
| 1 | {2,3} | 5 |
| 2 | {1,3} | 5 |
| 3 | {1,2} | 5 |
| 4 | {2,6} | 0 |
| 6 | {0,1} | 0 |

None is fault-tolerant, so rho(G,B)>=4. The C-signatures are also distinct, and B and C are disjoint. Their union is fault-tolerant: after erasure of a vertex from one of the two sets, the other resolving set remains intact. Thus B union C={0,1,2,5} is a feasible size-four superset and rho(G,B)=4. QED.

For completeness, the saved exhaustive certificate for this graph contains all 128 subsets and all 15 metric bases. It is additional evidence, not needed for the displayed direct argument. Order seven is the first order admitting positive penalty in the completed finite enumeration; this does not assert uniqueness of the example.

# 7. General bound

**Proof dependencies and review.** The complete argument uses the cited ordinary-resolution characterization. Separate AI sessions logically reviewed the proof, including a referee verdict of "proved as written" for the recorded proof revision. This is not human or journal peer review. The integrated elementary size-bound version and the reviewed formula-based revision are distinguished in the accompanying review report. The finite result in Section 3 stands independently and is not used to infer the arbitrary-order bound.

**Theorem 4.** Let G be a connected simple unweighted subcubic unicyclic graph, and let B be any metric basis of G. Then

\[
0\le \rho(G,B)-\beta_2(G)\le 1.
\]

The upper bound is sharp, as shown by Proposition 3. The proof follows from the lemmas and cases below, using the explicitly identified ordinary-resolution results of Sedlar and Skrekovski.

For the propositions, extend rho(G,B) and p(G,B) by the same formulas to any nonempty resolving set B, whether or not it is minimum. When discussing metric dimension we explicitly return to a metric basis.

## 7.1. A general union bound

**Lemma 5 (union bound).** If B is a nonempty resolving set of a connected graph with at least two vertices, then p(G,B)<=|B|-1. In particular, every metric basis of size two satisfies p<=1.

*Proof.* Let F be a minimum fault-tolerant set. If F intersects B, the fault-tolerant superset F union B has cardinality at most |F|+|B|-1. If the sets are disjoint, choose any f in F. Both F without f and B resolve, and are disjoint. Their union is fault-tolerant: erasing any one sensor leaves at least one of the two resolving sets intact. It contains B and has |F|+|B|-1 elements. Subtracting beta2=|F| gives the bound. QED.

## 7.2. Branch definitions and the imported characterization

Let C be the unique cycle. Removing the cycle edges partitions G into rooted trees T_v, one at each v in C. In a subcubic graph a *terminal fork* w is an off-cycle degree-three vertex with two child paths ending at leaves and with only degree-two internal vertices. These two paths are its terminal leafward threads. Let U_w be the union of their vertices, excluding w. Distinct U_w are disjoint. Let L be the number of terminal forks. A *branch-active root* is a cycle root v whose T_v contains an off-cycle degree-three vertex; let b count these roots. This graph-dependent notion is distinct from a root being *active for S*, meaning that S intersects T_v. A *direct cycle thread* is a leafward path attached at a cycle root with only degree-two internal vertices; its occupancy records whether S meets the path away from the root.

The dictionary to the cited source is especially simple here. A cycle vertex has at most one pendant thread. An off-cycle degree-three vertex has a direction leading toward the cycle and contributes a nonvacuous thread-coverage requirement exactly when its other two directions are terminal threads. Each such fork contributes one to the source parameter L(G), so L(G)=L. Being branch-resolving is therefore precisely the condition S intersect U_w is nonempty for every terminal fork w. This identifies both the source's branch parameter and its branch-resolving hypothesis before their use below.

We use Sedlar and Skrekovski [@sedlar-skrekovski], with numbering fixed to arXiv:2104.00577v1. Lemma 1 states that resolving sets are biactive and branch-resolving. Definition 5 and Lemmas 6-7 characterize resolution among such sets by excluding configurations A, B and C. These configurations depend on the active cycle roots, unoccupied pendant threads attached directly to the cycle, and the fixed thread lengths of the graph. The characterization applies to arbitrary biactive branch-resolving sets, not only minimum ones.

Consequently, if R is resolving and R' is branch-resolving with the same active cycle roots and the same occupancy of direct cycle threads as R, then R' resolves. The underlying graph and its thread lengths are unchanged in this use. In the subcubic setting, branch coverage requires precisely that every U_w be met: off-cycle vertices have at most two pendant threads, and cycle vertices at most one. We also use Lemma 3 of the same source: a branch-resolving set resolves if its active roots contain a geodesic triple. For cycle length g, three distinct roots u,v,w form such a triple when d_C(u,v)+d_C(v,w)+d_C(w,u)=g.

These are the source inputs identified and checked against the full preprint in the coordinating session-supplied proof review. The following proof uses elementary basis-size bounds rather than the stronger metric-dimension formula in Theorem 11. It therefore does not require that formula as an additional external premise.

## 7.3. Terminal-thread exchange

**Lemma 6 (terminal-thread exchange).** For a nonempty resolving set B in a subcubic unicyclic graph,

\[
p(G,B)\le |B|-L.
\]

*Proof.* At a terminal fork w, let u_1,u_2 be the first vertices on its two leafward threads. A vertex outside U_w has equal distance to u_1 and u_2, whereas every vertex in U_w has different distances to them. Therefore D_G(u_1,u_2)=U_w. Every resolving set meets U_w, and every fault-tolerant set has at least two vertices in U_w.

Choose B_0 by selecting one vertex of B in each U_w, so |B_0|=L. Starting with a minimum fault-tolerant F, for each selected B_0 vertex not already present replace one F vertex in the same U_w by that vertex. Disjointness of the U_w ensures these replacements have no interference or duplication. Write F' for the resulting set and let phi:F->F' be the bijection matching each replaced vertex to its replacement and fixing the others. Then |F'|=|F| and B_0 is contained in F'.

Fix z in F', and put x=phi^{-1}(z). The set F without x resolves. The set F' without z still meets every U_w, since F had at least two vertices in each such set and replacements preserve the count in each U_w, including after matched deletion. Replacements occur within the same attached rooted tree, so active cycle roots are unchanged relative to F without x. They occur on threads of off-cycle forks, not on direct cycle threads, so direct cycle thread occupancy is unchanged too. The imported characterization implies that F' without z resolves. This holds for every z, hence F' is fault-tolerant.

Adding B without B_0 to F' gives a fault-tolerant superset of B of cardinality at most |F|+|B|-L. Subtract beta2=|F|. QED.

**Consequence for metric bases.** If beta=L, then p=0 by this bound and nonnegativity. The elementary size bounds below will give the remaining case division.

### Elementary basis-size bounds

**Lemma 7.** If b>=2, then beta<=L+1; if b=1, then beta<=L+2; and if b=0, then beta<=3.

*Proof.* First, any two distinct vertices a,b on a cycle of length g>=3 can be completed to a geodesic triple. Choose a shortest a-b arc of length d<=floor(g/2); the complementary arc has length ell=g-d, with 2<=ell<=g-1. Choose an interior vertex c splitting that complementary arc into lengths floor(ell/2) and ceil(ell/2). Both lengths are at most floor(g/2), so each is a shortest cycle distance between its endpoints. Therefore

\[
d_C(a,b)+d_C(b,c)+d_C(c,a)=d+\ell=g.
\]

The chosen c is distinct from a and b. This covers antipodal a,b on an even cycle, as well as g=3: no endpoint or short-cycle exception is needed.

Choose one sensor in every U_w. This branch-resolving core has size L and activates exactly the b branch-containing roots. Indeed every such rooted tree contains a terminal fork, by taking a branching vertex farthest from the root. If b>=2, complete two already active roots to a geodesic triple using at most one additional cycle sensor. If b=1, choose a second root and then a third completing the triple, adding at most two sensors. If b=0, branch resolution is vacuous and any geodesic triple of cycle vertices suffices. Apply the cited geodesic-triple lemma in each case. QED.

For a metric basis, b>=2 now gives p<=1 by Lemma 6. The same applies when b=1 and beta<=L+1. Lemma 7 leaves only beta=L+2 in the one-branch-root case.

## 7.4. The one-branch-active-root case

**Lemma 8 (one branch-active root).** If b=1, beta(G)=L+2, and B is a metric basis, then p(G,B)<=1.

*Proof.* In a finite rooted subcubic tree containing a branching vertex, a deepest branching vertex has two terminal leafward threads; therefore b=1 implies L>=1. All terminal forks lie in the unique branch-containing rooted tree T_r. Apply Lemma 6's exchange construction to obtain a minimum fault-tolerant set F containing B_0, with one chosen B vertex in each U_w. Let C=B without B_0; then |C|=2.

If F meets C, F union B has at most |F|+1 vertices and is a sufficient superset. Otherwise F and C are disjoint. Since F resolves, the imported characterization ensures at least two active cycle roots. Choose z in F outside T_r. Every B_0 vertex lies inside T_r, and no vertex of C belongs to F, so z is not in B. Define S=B union (F without z). Then |S|=|F|+1 and S contains B.

We check every possible sensor erasure from S. If a vertex of C is erased, F without z remains, and resolves by fault tolerance of F. If a vertex of F without B is erased, the resolving set B remains. It remains to erase a vertex q of B_0. The set F without {z,q} is branch-resolving: each U_w originally contained at least two vertices of F, z lies outside T_r, and deleting q removes at most one vertex from one U_w. Relative to the resolving set F without z, the root r stays active because another F vertex remains in q's U_w. Other active roots are unchanged, as is occupancy of direct cycle threads. The characterization implies that F without {z,q} resolves, so the larger set S without q resolves. These cases exhaust S, proving fault tolerance. Thus rho<=|F|+1 and p<=1. QED.

## 7.5. No branch-active roots: odd cycles

Suppose b=0. Then each rooted attachment is a single path, possibly consisting only of its cycle root, and L=0. Write a vertex on the path attached at r as (r,t), where t>=0 is its distance from the cycle. Its distance to a cycle vertex q is t+d_C(r,q).

For an odd cycle of length 2h+1, h>=1, choose cycle vertices a,b at distance h. Consider the root difference d_C(r,a)-d_C(r,b). Along the h-edge arc from a to b its values are

\[
-h,-h+2,\ldots,h.
\]

At the h interior roots of the other arc, traversed from b to a, its values are

\[
h-1,h-3,\ldots,-h+1.
\]

Each list has distinct entries, and their parities differ, so all 2h+1 roots have different differences. The two distances from (r,t) to a and b identify r through their difference and then identify t from either distance. Therefore {a,b} resolves every such graph. The case h=1 includes a triangle and gives differences -1,1,0, so no short-cycle exception is suppressed.

No singleton can resolve a graph containing a cycle: if its sensor is in an attached path at r (including r itself), the two cycle neighbors of r have equal distance to that sensor. Hence beta=2. Lemma 5 gives p<=1 for every metric basis in this odd-cycle case.

## 7.6. No branch-active roots: even cycles

Let the cycle have even length 2h with h>=2. Lemma 7 gives beta<=3. A singleton cannot resolve, by the equal-distance cycle-neighbor argument. Lemma 5 already handles beta=2, so assume beta=3.

Every resolving set has at least two active cycle roots: if only r were active, its two cycle neighbors would have equal distance to every sensor. Furthermore a resolving set cannot have all its active roots in a single antipodal pair {a,a*}. The two cycle neighbors of a have distance one to a and distance h-1 to a*, and thus equal distances to every sensor in paths rooted at a or a*. They would remain unresolved. Consequently a metric basis B has two non-antipodal active roots a,b. Choose sensors x,y in B lying in their respective rooted paths.

Let a*,b* be the cycle antipodes of a,b. The four roots a,b,a*,b* are distinct because a and b are distinct and non-antipodal. The four sensors

\[
F=\{x,y,a^*,b^*\}
\]

also are distinct. After erasing any one of them, the three remaining sensors occupy three distinct roots and contain an antipodal pair of roots. Those three roots form a geodesic triple: for antipodes u,u* and any other cycle vertex v, one of the two semicircles contains v, so d_C(u,v)+d_C(v,u*)=h; adding d_C(u,u*)=h gives the cycle length 2h. This reasoning includes a four-cycle, where any triple of distinct roots contains an antipodal pair.

With b=0, the branch-resolving condition is vacuous. The cited geodesic-triple lemma therefore makes every one-sensor deletion from F resolving, so F is fault-tolerant and beta2<=4. For any graph here, a fault-tolerant set of size k leaves a resolving set of size k-1 after an erasure; hence beta2>=beta+1. Since beta=3, beta2=4. Finally, F contains x and y from B. Adding the remaining third vertex of B produces a fault-tolerant superset of size at most five. Thus rho(G,B)<=5 and p(G,B)<=1.

## 7.7. Completion and sharpness

For b>=2 the exchange bound and Lemma 7 give p<=1. For b=1 the same bound handles beta<=L+1 and Lemma 8 handles beta=L+2, exhausting Lemma 7's possibilities. For b=0, the odd-cycle argument gives beta=2; on an even cycle beta<=3, and the preceding construction handles the only remaining value beta=3. These cases exhaust connected subcubic unicyclic graphs. Nonnegativity was established in Section 2, completing Theorem 4. Proposition 3 supplies equality p=1, so the bound is sharp.

The completed proof has been separately logically reviewed. The bounded novelty assessment and its limitations are stated in Section 1. Neither the computation nor separate-agent review is described as human peer review.

# 8. Software, provenance and reproduction

The original computation used CPython 3.13.1, 64-bit, build `tags/v3.13.1:0671451, Dec 3 2024, MSC v.1942`, on Windows 11 platform string `Windows-11-10.0.26100-SP0`. The host reported ten logical CPUs; the primary runner restricted execution to one logical CPU. The graph generator, exact solvers and verifier use only the Python standard library, with no third-party mathematical package, GPU, stochastic choice or numerical tolerance in the original pilot. Section 9 uses separately recorded seeded input sampling with exact arithmetic.

The primary worker ran on 18 October 2026 from 10:56:33 to 10:56:44 UTC. It used 10.390625 CPU seconds and 10.904554 wall seconds, with peak resident working set 41,967,616 bytes. The launch plus synthetic resource tests used 12.859375 aggregate CPU seconds. Saved-output revalidation used 8.25 CPU seconds. Including a conservative two-second allowance for initial control setup and syntax checking, the original scientific/preflight charge was 23.109375 CPU seconds.

The separate external audit used 5.125 CPU seconds and 5.372638 wall seconds on its successful run, with peak resident working set 87,089,152 bytes. It conservatively charged under 30 CPU seconds including an instrumentation rerun. Thus the recorded combined charge is under 53.109375 CPU seconds against the original 7,200-second pilot budget. These timings exclude manuscript authoring and document rendering. The initial primary control setup failed closed on a page-rounded memory-cap equality check; the audit's initial run failed during memory reporting due to a ctypes handle-width error. Both are documented instrumentation events, not mathematical discrepancies.

The primary Windows runner uses nested Job Objects, single-CPU affinity, committed-memory and active-process limits, process hard working-set maxima, and wall watchdogs. The external audit instead measured memory and used a cooperative CPU guard, with no hard memory quota; it must not be described as inheriting the primary worker's enforcement. Precise page-rounded primary cap readbacks were checked but not retained. All observed memory use was well below the 4 GB envelope.

Original commands, run from the pilot directory, were:

```powershell
python launch.py
python audit_saved.py
```

The launcher refuses to overwrite its existing launch ledger or run directory. Reproduction should use a fresh isolated copy of the recorded sources and frozen preparation artifacts, preserving the delivered evidence. The public packaging step did not execute those scientific commands again. The public pilot audit runs with `python pilot-audit/audit.py` from a fresh release copy. Public audit path adaptations are documented in PROVENANCE.json; original source hashes are retained. Reference outputs must be preserved before any rerun.

The evidence consists of `graphs.jsonl`, `bases.jsonl`, `certificates.jsonl`, `coverage.json`, `manifest.json`, the saved-artifact audit, and the separate external-audit files. The manifest records input hashes before and after execution and output hashes. `PROVENANCE.json` alongside this manuscript pins the public files used here. The delivered ZIP's package manifest pins its contents, including the audit copies.

Key SHA-256 hashes:

```text
generate.py  72b31a974050a9eaa8d275758932756706782c3d47d93b023d686412c20f49cb
solve.py     e06c139310458cb54a81d6648ac161068d499f697ae578811375191b93b3963f
verify.py    2927b07bd449dd21e28a220417c53d55e38515d868353ab86eaa8e2dd6c501cc
graphs.jsonl 62e60f9bb99846634ed134a1340e4d054fc33600676bf68f1271f1e82db94f17
bases.jsonl  a9fc7c35757ac5e680c06ef315ff1fa6e0660b1168924759bed8acc94703d18e
certificates.jsonl
11569ee3a65bd4b46d209278a7a67b3c991bf2c5ef45fe062e53bc96270cfff1
```

# 9. Computational robustness extension

The local protocol, case plan and source hashes were recorded before the recorded extension run; the runner checked those hashes before solving. These files provide a local freeze, not an independently timestamped preregistration. Their mutable local timestamps cannot establish the absence of earlier unrecorded analyses. The seed was 20261018; every sampled input is retained.

The 71 original graph classes through eight vertices supplied the baseline seeds. Three unequal positive-integer edge-length assignments in {1,2,3,4} per seed yielded 213 weighted cases. Attaching a leaf to the first eligible degree-three vertex yielded 28 unicyclic degree-four cases. Adding the first eligible nonedge yielded 70 subcubic two-cycle cases. These deterministic, label-dependent variants are finite stress tests, not exhaustive coverage of the larger classes. All minimum ordinary metric bases of each case were included.

| Family | Cases | Minimum bases | p=0 | p=1 |
|---|---:|---:|---:|---:|
| Unit-length baseline | 71 | 697 | 679 | 18 |
| Unequal integer lengths | 213 | 1,337 | 1,317 | 20 |
| Unicyclic, degree four | 28 | 278 | 198 | 80 |
| Subcubic, two cycles | 70 | 672 | 602 | 70 |
| Total | 382 | 2,984 | 2,796 | 188 |

All 382 cases completed, with no stopping-rule skips or premium above one, across 68,576 subset entries. Three two-cycle cases repeat labelled edge lists; the 70 cases represent 67 distinct labelled graphs. No isomorphism-distinct extension count is claimed. Passing these cases does not extend Theorem 4 beyond its unweighted, subcubic, unicyclic hypotheses.

## 9.1. Bounded-error separation

Each surviving coordinate has reading d(v,s)+e_s, where |e_s| is at most epsilon; errors vary independently and adversarially within closed intervals. One identified sensor erasure deletes a coordinate, not a target vertex, and leaves graph distances unchanged. For each target pair, sort the absolute coordinate gaps |d(u,s)-d(v,s)|. Let m1(S) be the minimum over pairs of the largest gap, and m2(S) the minimum over pairs of the second-largest gap; missing gaps are zero. Uniform distinguishability without loss requires m1(S)>2 epsilon; after any one identified erasure it requires m2(S)>2 epsilon. This is an exact error-box criterion, not a numerical tolerance rule. At equality the boxes intersect, so an ambiguous permitted observation exists; this does not mean every observation is ambiguous.

For any connected unit-edge graph with at least two vertices and any exact fault-tolerant layout S, m2(S)=1. Integer distances and two distinguishers imply m2(S)>=1. For adjacent targets u,v, the triangle inequality gives |d(u,s)-d(v,s)|<=1 for every sensor, implying m2(S)<=1. Thus its worst-case one-erasure guarantee holds exactly for epsilon<1/2. The unit-edge measurements are consistency checks of this generic fact, not a new experimental or graph-class-specific discovery. Integrality likewise makes every integer-distance FT layout pass at epsilon=1/4. An ordinary minimum basis has m2=0 by minimality, since deleting any sensor cannot leave a resolving set. No half-unit assertion is made for arbitrary integer-weighted graphs.

The experiment evaluated epsilon=0,1/4,1/2,1 for each minimum basis, its smallest-mask optimum FT augmentation, and one smallest-mask unconstrained FT optimum per case. Among 1,337 weighted augmentation rows, m2 was 1 for 1,300 rows, 2 for 24, and 3 for 13. Accordingly, 37 passed at epsilon=1/2 and 13 at epsilon=1. These are deterministic counts conditioned on bases, possibly sharing layouts, not independent trials or probabilities. Margin-optimal choices among tied layouts and minimum robust sensor sets were not searched. Weighted margins depend on length units and were not normalised across graph scales; larger absolute margins do not establish improved physical sensing. No stochastic error distribution or physical calibration is asserted.

## 9.2. Independent verification and evidence

A separately authored executable audit reproduced the complete finite case plan, all optima and noise certificates; this is AI computational review, not human peer review or physical validation. It independently rebuilt the cases, used Bellman-Ford distances, and checked exhaustive signature/deletion tables. Every one of the 4,675 per-case unique-layout boundary certificates was verified by enumerating target pairs and erased coordinates. Each contains an ambiguous pair and midpoint readings at epsilon=m2/2. The reviewed files and exact hashes are recorded in the bundled `extension-audit/AUDIT.md` and `extension-audit/audit-result.json`; `extension_audit.py` has documented portable path adaptations; the original reviewed source hash is retained. The reviewed result and noise-certificate hashes are:

```text
results.jsonl
c202b7e2d20554255bf54f4ffdff6b069593321c3c8dff1ee22f25f6016d4c32
noise-boundary-certificates.jsonl
f3fe7a989b6e89d989005383934ee789c94009d2766ca29324576bef24fd4423
```

The producer's core and postcheck recorded 2.625 CPU seconds, with peak working set below 52 MB. The separate audit recorded 0.90625 CPU seconds and 54,587,392 bytes peak working set; minor inspection, setup, summarisation and packaging overhead is not aggregated in these subtotals. The core enforced a one-process, one-CPU Job Object with a 1,100-second wall watchdog and 3.3 GB committed-memory cap, plus a 3.0 GB working-set cap. The separate audit used a cooperative CPU guard and measured memory, without a hard memory quota. Resource enforcement was not stress-tested again by that audit. No new scientific cases were run for manuscript integration.

# 10. Interpretation and limitations

The quantity p isolates the cost of preserving a given metric basis in a cardinality objective. For the example, retaining two original sensors requires two additions and four total sensors; a freely redesigned fault-tolerant solution uses three total sensors. This does not assign monetary costs to adding, moving or removing a sensor, and it does not establish an engineering advantage for either policy.

The main theorem assumes exact graph distances, equal edge lengths and identification of the erased coordinate. Section 9 separately studies finite weighted/topology variants and an uncalibrated bounded-error model. It is not a model of water pressure, hydraulic flow, noisy observations, leaks, unknown sensor errors or physical network performance. No physical or network utility follows from the finite result.

The computation excludes graphs of order above ten. Theorem 4 covers arbitrary finite orders through a separate argument, not extrapolation. Both are restricted to the stated graph class and fault model. The finite stress tests in Section 9 do not establish a universal extension to larger maximum degree, weighted or multicyclic graphs; directed graphs, multigraphs and graph-vertex deletion faults remain outside the analysis. Independent executable agreement still trusts Python, the operating environment and the completeness/canonicalization arguments. No proof assistant was used. The proof begins with an optimal fault-tolerant set and is not by itself a polynomial-time optimization algorithm. Its sensor-count interpretation does not demonstrate noisy-distance robustness, hydraulic validity or field performance.

# 11. AI assistance and draft status

This draft was prepared under timofy's direction with AI assistance in developing and checking mathematical arguments, implementing and auditing computations, literature searching and comparison, and manuscript drafting and editing. Separate AI sessions performed logical and computational checks. Those checks are not independent human peer review, journal review or a formal proof-assistant verification. No affiliation or ORCID is asserted. This is a publicly shared AI-assisted research draft. No human peer review has been undertaken and no journal acceptance is claimed. The bounded search does not guarantee originality; timofy coordinates the project; the recorded reviews are AI logical and computational checks.

# References

The companion bibliography gives the checked source versions and available publication metadata. Numbering of the structural inputs follows arXiv:2104.00577v1, rather than assuming identical numbering in all versions. The Geneson-Tsai citation deliberately identifies the checked preprint instead of supplying unverified final journal metadata.
